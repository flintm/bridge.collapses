# FUNCTION THAT FINDS MATCHES TO KEYWORD STRINGS IN THE ROAD_NAME FIELD, REMOVES STRINGS AS APPROPRIATE,
# AND APPENDS TO APPROPRIATE CATEGORY
# WRITTEN BY MADELEINE FLINT, DECEMBER 2014

GetAndRemoveLocationData <- function(FailDataRow, LocMatch, LocProcessColsOut, ls.JurisdictionKeys, ls.RoadKeys, ls.StreamKeys, CityLoc = FALSE, strict=FALSE){
 # print(CityLoc)
  if (CityLoc) {
    match_words_loc <- ls.JurisdictionKeys$city
    replace_word    <- "city"
  }
  else { 
    match_words_loc <- ls.JurisdictionKeys$county
    replace_word    <- "county"
  }
  nLocMatchWords   <- length(match_words_loc)
  match_words_rd   <- c(ls.RoadKeys$avenue,ls.RoadKeys$road[1:2],ls.RoadKeys$street, ls.RoadKeys$bridge)
  match_words_w_rd <- as.vector(sapply(match_words_rd, function(s) paste(match_words_loc,s,sep=" ")))
  match_words_w_rd[(length(match_words_w_rd)+1):(length(match_words_w_rd)+length(match_words_rd))] <- match_words_rd
  nMatchWordsRd    <- length(match_words_w_rd)
  nMatchWords      <- nMatchWordsRd + nLocMatchWords
  match_words_w_rd[(nMatchWordsRd+1):nMatchWords] <- match_words_loc
  check_match                 <- unlist(lapply(c(paste("\\<",gsub("[[:punct:]]"," ",LocMatch),"\\>"," ",match_words_w_rd, sep="")), function(p) grepl(p, gsub("[[:space:]]+|[[:space:]]"," ", gsub("[[:punct:]]"," ",FailDataRow[,"ROAD_NAME"])))))
  check_match[nMatchWords+1]  <- grepl(paste("\\<",gsub("[[:punct:]]"," ",LocMatch),"\\>", sep=""), gsub("[[:space:]]+|[[:space:]]"," ", gsub("[[:punct:]]"," ",FailDataRow[,"ROAD_NAME"])))
  
  match_words_stream   <- unlist(ls.StreamKeys)
  check_match_stream   <- unlist(lapply(c(paste("\\<",gsub("[[:punct:]]"," ",LocMatch),"\\>"," ","\\<",match_words_stream,"\\>", sep="")), function(p) grepl(p, gsub("[[:space:]]+|[[:space:]]"," ", gsub("[[:punct:]]"," ",FailDataRow[,"ROAD_NAME"])))))
  first_match    <- ifelse(any(check_match),
                           ifelse(min(which(check_match))<=nMatchWordsRd,
                                  -2,
                                  ifelse(min(which(check_match))<=nMatchWords,
                                         which(check_match),
                                         ifelse(any(check_match_stream),
                                                -1,
                                                0))),
                           -2)
  
  if (first_match > 0) { # remove whole phrase from ROAD_NAME, place in ROAD_NEAR
    match_start    <- regexpr(paste("\\<",LocMatch,"\\>[[:print:]]{0,3}\\<",match_words_w_rd[first_match],"\\>", sep=""),FailDataRow[,"ROAD_NAME"]) 
    match_last     <- match_start + attr(match_start, "match.length") - 1 #
    temp_entry <- FailDataRow[,"ROAD_NAME"]
    FailDataRow[,"ROAD_NAME"] <- paste(substr(temp_entry,1,match_start-1),substr(temp_entry,match_last+1,nchar(temp_entry)),sep="")
    if (!grepl(LocMatch,FailDataRow[,"ROAD_NEAR"])) { # (but only if it's not already there)
      FailDataRow[,"ROAD_NEAR"] <- paste(FailDataRow[,"ROAD_NEAR"],LocMatch,replace_word, "-", sep=" ")
    }
  }
  if (first_match == 0){
    if (strict == FALSE){
      FailDataRow[,"ROAD_NAME"] <- gsub(paste("\\<",LocMatch,"\\>", sep = ""),"", FailDataRow[,"ROAD_NAME"])
    }
    if (!grepl(LocMatch,FailDataRow[,"ROAD_NEAR"])) {
      FailDataRow[,"ROAD_NEAR"] <- paste(FailDataRow[,"ROAD_NEAR"],LocMatch, "-", sep=" ")
    }
    FailDataRow[,"FLAG_LOCATION"]  <- FailDataRow[,"FLAG_LOCATION"] + 1
  }
  if (first_match == -1){
    stream_word    <- match_words_stream[check_match_stream]
    match_start_loc    <- regexpr(paste("\\<",LocMatch,"\\>", sep=""),FailDataRow[,"ROAD_NAME"])
    match_last_loc     <- match_start_loc + attr(match_start_loc, "match.length") - 1
    match_start_stream    <- regexpr(paste("\\<",stream_word,"\\>", sep=""),FailDataRow[,"ROAD_NAME"])
    if (match_start_stream < match_start_loc){
      FailDataRow[,"ROAD_NAME"] <- gsub(paste("\\<",LocMatch,"\\>", sep = ""),"", FailDataRow[,"ROAD_NAME"])
      if (!grepl(LocMatch,FailDataRow[,"ROAD_NEAR"])) {
        FailDataRow[,"ROAD_NEAR"] <- paste(FailDataRow[,"ROAD_NEAR"],LocMatch, "-", sep=" ")
      }
      FailDataRow[,"FLAG_LOCATION"]  <- FailDataRow[,"FLAG_LOCATION"] + 1
    }
  } 
return(FailDataRow[,LocProcessColsOut])
}
