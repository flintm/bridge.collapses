# cleans up FailDataFrame to get associated ITEM43A (mat) ITEM43B (type) according to NBI

library(stringr)
# STEP 0A: BRIDGE STRUCTURE TYPES AND PRIMARY MATERIALS -----------------------------------------------
# Item 43B - Structure Type, Main
# The second and third digits indicate the predominant type of design
# and/or type of construction and shall be coded using one of the
# following codes:
#
#  Code    Description
#  01      Slab
#  02      Stringer/Multi-beam or Girder
#  03      Girder and Floorbeam System
#  04      Tee Beam
#  05      Box Beam or Girders - Multiple
#  06      Box Beam or Girders - Single or Spread
#  07      Frame (except frame culverts)
#  08      Orthotropic
#  09      Truss - Deck
#  10      Truss - Thru
#  11      Arch - Deck
#  12      Arch - Thru 
#  13      Suspension
#  14      Stayed Girder (cable-stayed)
#  15      Movable - Lift
#  16      Movable - Bascule
#  17      Movable - Swing
#  18      Tunnel
#  19      Culvert (includes frame culverts)
#  20 *    Mixed types
#  21      Segmental Box Girder
#  22      Channel Beam
#  00      Other
#    * Applicable only to approach spans - Item 44                             
StructTypes.NBI_no     <- c( c(1:22), 0 )

ls.StructTypes.NBI <- list(slab    = c("1", "slab"), 
                           string  = c("2", "stringer", "multi beam", "girder"), 
                           grdFlr  = c("3", "girder floorbeam"),
                           tBeam   = c("4", "t beam", "tee beam"), 
                           boxMult = c("5", "box beam multiple", "box girder multiple", "multiple box beam", "multiple box girder"), 
                           boxSing = c("6", "box beam single", "box beam spread", "box girder single", "box girder spread"),
                           frame   = c("7", "frame"), 
                           ortho   = c("8", "orthotropic"), 
                           trussD  = c("9", "truss deck", "deck truss"),
                           trussT  = c("10", "truss thru", "truss through", "thru truss", "through truss"), 
                           archD   = c("11", "arch deck", "deck arch"), 
                           archT   = c("12", "arch thru", "arch through", "thru arch", "through arch"),
                           susp    = c("13", "suspension"), 
                           styGrd  = c("14", "stayed girder"), 
                           mvLift  = c("15", "movable lift", "lift"),
                           mvBasc  = c("16", "movable bascule", "bascule"), 
                           mvSwng  = c("17", "movable swing", "swing"), 
                           tunnel  = c("18", "tunnel"),
                           culvert = c("19", "culvert"), 
                           mixed   = c("20", "mixed approach", "mixed"), 
                           seg     = c("21", "segmental box girder"),
                           chnlBm  = c("22", "channel beam"), 
                           other   = c("0", "other"))

# map failure database to NBI codes
# ASSUMING THAT TRUSS = TRUSS THRU AND ARCH = DECK ARCH, BOX BEAM = SINGLE
# ASSUME SPAN = SLAB
ls.StructTypes.Fail <- list(slab   = c("1", "slab", "span"), 
                            string  = c("2", "stringer", "multi beam", "girder", "mult beam", "thru girder", "702", "multi gird", "beam",
                                        "rolled beam", "flatcar", "i beam", "w beam", "two girder","rolled bm"), 
                            grdFlr  = c("3", "girder floorbeam", "girder fb"),
                            tBeam   = c("4", "t beam", "tee beam", "tbeam"), 
                            boxMult = c("5", "box beam multiple", "box girder multiple", "multiple box beam", "multiple box girder"), 
                            boxSing = c("6", "box beam single", "box beam spread", "box girder single", "box girder spread", "box beam", "box"),
                            frame   = c("7", "frame", "rigid frame", "rigid"), 
                            ortho   = c("8", "orthotropic"), 
                            trussD  = c("9", "truss deck", "deck truss"),
                            trussT  = c("10", "truss thru", "truss through", "thru truss", "through truss", "truss beam", "truss prat",
                                        "truss pony", "pony truss", "truss grdr", "high truss", "bailey", "covered", "truss"), 
                            archD   = c("11", "arch deck", "deck arch", "filled arch", "jack arch", "arch"), 
                            archT   = c("12", "arch thru", "arch through", "thru arch", "through arch", "tied arch"),
                            susp    = c("13", "suspension"), 
                            styGrd  = c("14", "stayed girder"), 
                            mvLift  = c("15", "movable lift", "lift"),
                            mvBasc  = c("16", "movable bascule", "bascule"), 
                            mvSwng  = c("17", "movable swing", "swing"), 
                            tunnel  = c("18", "tunnel"),
                            culvert = c("19", "culvert", "box culvert", "pipe", "pipe arch", "corrugated pipe","rcb"), 
                            mixed   = c("20", "mixed approach", "mixed"), 
                            seg     = c("21", "segmental box girder"),
                            chnlBm  = c("22", "channel beam"), 
                            other   = c("0", "other", "trestle", "deck girder"))

# combine
ls.StructTypes <- mapply(c,ls.StructTypes.NBI,ls.StructTypes.Fail)
ls.StructTypes <- lapply(1:length(ls.StructTypes), function(i) unique(ls.StructTypes[[i]]))
names(ls.StructTypes) <- names(ls.StructTypes.Fail)

# ITEM 43A bridge materials
# The first digit indicates the kind of material and/or design and shall
# be coded using one of the following codes:
# Code             Description
# 1                Concrete
# 2                Concrete continuous
# 3                Steel
# 4                Steel continuous
# 5                Prestressed concrete *
# 6                Prestressed concrete continuous *
# 7                Wood or Timber
# 8                Masonry
# 9                Aluminum, Wrought Iron, or Cast Iron
# 0                Other
# * Post-tensioned concrete should be coded as prestressed concrete.
StructMat.NBI_no <- c( c(1:9), 0 )

ls.StructMat.NBI <- list(conc       = c("1", "concrete"), 
                         conc_cont  = c("2", "concrete continuous"),
                         steel      = c("3", "steel"),
                         steel_cont = c("4", "steel continuous"),
                         pc         = c("5", "prestressed concrete"),
                         pc_cont    = c("6", "prestressed concrete continuous"),
                         wood       = c("7", "wood", "timber"),
                         masonry    = c("8", "masonry"),
                         metal      = c("9", "aluminum", "cast iron", "wrought iron"),
                         other      = c("10", "other"))

ls.StructMat.Fail   <- list(pc      = c("prestressed concrete", "prestress concrete", "pc concrete", 
                                        "pc concret", "concrete prestress", "prestressed conc", "prestress", 
                                        "pc", "p s concrete", "p s conc","p s", "ps","5","6"), 
                            conc    = c("concrete", "concret", "conc","1","2"), 
                            steel   = c("steel","3","4"), 
                            wood    = c("wood", "timber", "log","7"),
                            masonry = c("masonry", "stone","8"), 
                            metal   = c("aluminum", "cast iron", "wrought iron", "wrght iron", "iron", "alum", "cor metal", "metal", "iron","9"), 
                            other   = c("other", "conc timb", "conc steel", "steel timb", "steel wood", "wood steel","steel conc", "0"))

ls.StructSup   <- list(simple = c("simply supported", "simple", "smp", "simp", "ss"), 
                       cont = c("continuous", "contin", "cont", "con", "cnt"))


# data frame that matches material and support type to NBI 43A material code
df.Map.StructMatSup <- data.frame(as.integer(c(1, 1, 1, 2, 2, 2, 3, 3, 3, 4, 5, 6, 7)),as.integer(c(1,2,NA,1,2,NA,1,2,NA,NA,NA,NA,NA)),
                                  c("5", "6", "5", "1", "2", "1", "3", "4", "3", "7", "8", "9","0"),stringsAsFactors = FALSE)
colnames(df.Map.StructMatSup) <- c("MAT", "SUP", "NBI43A")

# STEP 1B: CHECK FOR ERRORS IN DATA ENTRY (E.G., MATERIAL DATA IN "TYPE" VARIABLE) ---------------------------------------
# MAKE FLAG COLUMNS - ADD +1 IF MANIPULATED THAT ROW (USE LATER ON TO DECIDE WHETHER OR NOT TO LOOSEN
# SEARCH PARAMETERS WHEN TRYING TO MATCH BRIDGE)
FailDataFrameTypes <- c("integer", "character", "character", "character", "character", "character","character", "YYYY",      "YYYY",      "d-b-y",
FailDataFrame.Char <- c("LOCATION", "FEAT_UND", "TYPE", "MAT", "FAIL_CAUS")
FailDataFrame$FLAG_TYPES    <- integer(nrow(FailDataFrame))

# check for cross-listing of types and materials in failure database and append as appropriate
# first remove types from material and append to type column
FailRowNames  <- rownames(FailDataFrame)
nonEmptyRows <- rownames(FailDataFrame[FailDataFrame$MAT!="",])
for (j in c(1:length(ls.StructTypes))){
  key_index <- sapply(1:length(nonEmptyRows), function(i) ifelse(any(!is.na(pmatch(ls.StructTypes[[j]],FailDataFrame[nonEmptyRows[i],"MAT"],))),
                                                                 which(!is.na(pmatch(ls.StructTypes[[j]],FailDataFrame[nonEmptyRows[i],"MAT"]))),
                                                                 NA_integer_))
  match_keys <- which(!is.na(key_index))  
  #   if (length(match_keys)) {print(c("For structure type ", names(ls.StructTypes)[j], ", matched rows are:"))
  #                            print(nonEmptyRows[match_keys])
  #                            print(c("resulting in substitutions of words or numbers:"))}
  for (i in match_keys){
    #     print(ls.StructTypes[[j]][key_index[i]])
    #     print("from entries:")
    #     print(FailDataFrame[nonEmptyRows[i],c("TYPE", "MAT")])
    #     print("to entries:")
    FailDataFrame[nonEmptyRows[i],"MAT"] <- gsub(ls.StructTypes[[j]][key_index[i]],"",FailDataFrame[nonEmptyRows[i],"MAT"])
    # only paste into TYPE if TYPE does not already contain the same information
    if (all(is.na(pmatch(ls.StructTypes[[j]],FailDataFrame[nonEmptyRows[i],"TYPE"])))){
      FailDataFrame[nonEmptyRows[i],"TYPE"] <- paste(FailDataFrame[nonEmptyRows[i],"TYPE"],ls.StructTypes[[j]][key_index[i]],sep=" ")
      FailDataFrame[nonEmptyRows[i], "FLAG_TYPES"] <- FailDataFrame[nonEmptyRows[i], "FLAG_TYPES"] + 1
    }
    #   print(FailDataFrame[nonEmptyRows[i],c("TYPE", "MAT")])
  }
  #   if (length(match_keys)) print("------------")
}
print("Finished error-checking for FailDataFrame MAT")

# remove materials from types
nonEmptyRows <- rownames(FailDataFrame[FailDataFrame$TYPE!="",])
for (j in c(1:length(ls.StructMat.Fail))){
  key_index <- sapply(1:length(nonEmptyRows), function(i) ifelse(any(!is.na(pmatch(ls.StructMat.Fail[[j]],FailDataFrame[nonEmptyRows[i],"TYPE"]))),
                                                                 which(!is.na(pmatch(ls.StructMat.Fail[[j]],FailDataFrame[nonEmptyRows[i],"TYPE"]))),
                                                                 NA_integer_))
  match_keys <- which(!is.na(key_index))
  #   if (length(match_keys)) {print(c("For material type ", names(ls.StructMat.Fail)[j], ", matched rows are:"))
  #                                 print(nonEmptyRows[match_keys])
  #   print(c("resulting in substitutions of words or numbers:"))}
  for (i in match_keys){
    #     print(ls.StructMat.Fail[[j]][key_index[i]])
    #     print("from entries:")
    #     print(FailDataFrame[nonEmptyRows[i],c("TYPE", "MAT")])
    #     print("to entries:")
    FailDataFrame[nonEmptyRows[i],"TYPE"] <- gsub(ls.StructMat.Fail[[j]][key_index[i]],"",FailDataFrame[nonEmptyRows[i],"TYPE"])
    if (all(is.na(pmatch(ls.StructMat.Fail[[j]],FailDataFrame[nonEmptyRows[i],"MAT"])))){
      FailDataFrame[nonEmptyRows[i],"MAT"] <- paste(ls.StructMat.Fail[[j]][key_index[i]],FailDataFrame[nonEmptyRows[i],"MAT"],sep=" ")
      FailDataFrame[nonEmptyRows[i], "FLAG_TYPES"] <- FailDataFrame[nonEmptyRows[i], "FLAG_TYPES"] + 1
    }
    #     print(FailDataFrame[nonEmptyRows[i],c("TYPE", "MAT")])
  }
  #   if (length(match_keys)) print("------------")
}
print("Finished error-checking for FailDataFrame TYPE")

# remove support (simple or continuous) from types
nonEmptyRows <- rownames(FailDataFrame[FailDataFrame$TYPE!="",])
for (j in c(1:length(ls.StructSup))){
  key_index <- sapply(1:length(nonEmptyRows), function(i) ifelse(any(!is.na(pmatch(ls.StructSup[[j]],FailDataFrame[nonEmptyRows[i],"TYPE"]))),
                                                                 which(!is.na(pmatch(ls.StructSup[[j]],FailDataFrame[nonEmptyRows[i],"TYPE"]))),
                                                                 NA_integer_))
  match_keys <- which(!is.na(key_index))
  for (i in match_keys){
    FailDataFrame[nonEmptyRows[i],"TYPE"] <- gsub(ls.StructSup[[j]][key_index[i]],"",FailDataFrame[nonEmptyRows[i],"TYPE"])
    if (all(is.na(pmatch(ls.StructSup[[j]],FailDataFrame[nonEmptyRows[i],"MAT"])))){
      FailDataFrame[nonEmptyRows[i],"MAT"] <- paste(FailDataFrame[nonEmptyRows[i],"MAT"],ls.StructSup[[j]][key_index[i]],sep=" ")
    }
  }
}


# clean up and separate material and support type (simple or continuous)
FailDataFrame[,FailDataFrame.Char] <- sapply(1:length(FailDataFrame.Char), function(i) str_trim(FailDataFrame[,FailDataFrame.Char[[i]]]))
FailDataFrame[,FailDataFrame.Char] <- sapply(1:length(FailDataFrame.Char), function(i) gsub("[[:space:]]+|[[:space:]]"," ",FailDataFrame[,FailDataFrame.Char[[i]]]))
FailDataFrame[,"MATER"] <- FailDataFrame$MAT
FailDataFrame[,"SUPPORT"] <- character(nrow(FailDataFrame))

PossSupportRows <- sapply(1:nrow(FailDataFrame), function(i) ifelse(length(unlist(str_split(FailDataFrame[i,"MATER"]," ")))>1 & all(is.na(match(unlist(ls.StructMat.Fail),FailDataFrame[i,"MATER"]))),rownames(FailDataFrame[i,]),NA)) 
PossSupportRows <- PossSupportRows[!is.na(PossSupportRows)]
#print("Checking entries:")
#print(FailDataFrame[PossSupportRows, "MATER"])

empty_int <- integer(length(unlist(ls.StructSup)))
split_key_index <- data.frame(empty_int, empty_int, empty_int, empty_int, empty_int)
key_index_row <- integer(5)
for (i in PossSupportRows){
  #  print(paste("number of split strings in row",i,"is:",length(unlist(str_split(FailDataFrame[i,"MATER"]," "))),sep=" "))
  for (j in 1:length(unlist(str_split(FailDataFrame[i,"MATER"]," ")))){
    split_key_index[,j] <-  match(unlist(ls.StructSup),unlist(str_split(FailDataFrame[i,"MATER"]," "))[j])
    # print(split_key_index[,j])
    key_index_row[j] <- ifelse(any(!is.na(split_key_index[,j])),which(!is.na(split_key_index[,j])),NA_integer_)
    # print(key_index_row[j])
  }
  #  print(key_index_row[1:j])
  key_index <- key_index_row[!is.na(key_index_row)]
  split_key_index <- data.frame(empty_int, empty_int, empty_int, empty_int, empty_int)
  key_index_row <- integer(5)  
  if (length(key_index)){
    
    #   print(paste("matching on word",unlist(ls.StructSup)[key_index],"in entry:",FailDataFrame[i,"MATER"],sep = " "))
    FailDataFrame[i,"MATER"]   <- gsub(paste("\\<",unlist(ls.StructSup)[key_index],"\\>",sep=""),"",FailDataFrame[i,"MATER"])
    FailDataFrame[i,"SUPPORT"] <- unlist(ls.StructSup)[key_index]
  }
}

print("Finished separation of TYPE, MATER, and SUPPORT")

FailDataFrame$MATER <- str_trim(FailDataFrame$MATER)

#####################################################################################################################################
#  LINK TO ITEM43A AND ITEM43B FROM NBI DATA - BECAUSE LIMITED DATA ON CONTINUITY, NEED TO FIND POPULAR TYPES IN NBI TO INFER -------
# Get type for those that have
rowsWithType <- FailRowNames[FailDataFrame$TYPE!=""]
nonEmptyRows <- rowsWithType

# one-off for rcb, iowa reinforced concrete box culvert
FailDataFrame[FailDataFrame$TYPE=="rcb",c("MATER","SUPPORT")] <- c("concrete", "simple")

# ASSIGN TYPES
for (j in 1:length(ls.StructTypes.Fail)){
  key_index <- sapply(1:length(nonEmptyRows), function(i) any(!is.na(pmatch(ls.StructTypes.Fail[[j]],FailDataFrame[nonEmptyRows[i],"TYPE"]))))
  FailDataFrame[nonEmptyRows[key_index],"ITEM43B"] <- as.integer(ls.StructTypes.Fail[[j]][1])
}

# see how types compares
df.types                <- data.frame(TYPE=c(levels(factor(nbiDataFrame$ITEM43B)), levels(factor(FailDataFrame$ITEM43B))),COUNT=NA,DATA=NA)
df.types[1:22,"COUNT"]  <- sapply(levels(factor(nbiDataFrame$ITEM43B)), function(t) sum(nbiDataFrame[!is.na(nbiDataFrame$ITEM43B),"ITEM43B"]==t))
df.types[1:22,"DATA"]   <- "NBI_WATER"
df.types[23:36,"COUNT"] <- sapply(levels(factor(FailDataFrame$ITEM43B)), function(t) sum(FailDataFrame[!is.na(FailDataFrame$ITEM43B),"ITEM43B"]==t))
df.types[23:36,"DATA"]  <- "FAIL_WATER"
df.types[1:22,"FREQ"]   <-  df.types[1:22,"COUNT"]/sum(df.types[1:22,"COUNT"])
df.types[23:36,"FREQ"]  <-  df.types[23:36,"COUNT"]/sum(df.types[23:36,"COUNT"])
hist1 <- ggplot(df.types,aes(x=TYPE,y=FREQ,fill=factor(DATA))) + geom_bar(stat="identity",position="dodge")

  # -> low on culverts (19), which is probably OK, high on 10 (truss thru), missing 5, way low, high on 2

# ASSIGN MATERIAL
# first tackle those with support
rowsWithSupport <- FailRowNames[FailDataFrame$SUPPORT!=""]
nonEmptyRows <- rowsWithSupport

matsToCheck <- c("pc","conc","steel")
for (j in 1:length(matsToCheck)){
  key_index <- sapply(1:length(nonEmptyRows), function(i) any(ls.StructMat.Fail[[matsToCheck[j]]]==FailDataFrame[nonEmptyRows[i],"MATER"]))
  match_keys <- which(key_index)
  for (i in match_keys){
    if(any(grepl(FailDataFrame[nonEmptyRows[i],"SUPPORT"],ls.StructSup[["simple"]]))){
      # use fact that continuous always has a higher material # than simple--will cause warning beacuse of conversion to integer
      FailDataFrame[nonEmptyRows[i],"ITEM43A"] <- min(as.integer(ls.StructMat.Fail[[matsToCheck[j]]]),na.rm=TRUE)
    }
    else{
      FailDataFrame[nonEmptyRows[i],"ITEM43A"] <- max(as.integer(ls.StructMat.Fail[[matsToCheck[j]]]),na.rm=TRUE)
    }
  }
}

# now try ones with single match (ie, timber)
nonEmptyRows <- FailRowNames[FailDataFrame$MATER!="" & is.na(FailDataFrame$ITEM43A)]

matsToCheck <- c("wood", "masonry", "metal", "other")
for (j in 1:length(matsToCheck)){
  key_index <- sapply(1:length(nonEmptyRows), function(i) any(ls.StructMat.Fail[[matsToCheck[j]]]==FailDataFrame[nonEmptyRows[i],"MATER"]))
  match_keys <- which(key_index)
  for (i in match_keys){
    # just want the numeric, doesn't need to be min but convenient
    FailDataFrame[nonEmptyRows[i],"ITEM43A"] <- min(as.integer(ls.StructMat.Fail[[matsToCheck[j]]]),na.rm=TRUE)
  }
}

# try to assign when missing based on most popular option that matches material
# do this based on most common assignment for bridges built +/-n years from build date with same type
yearsBuildRange <- 3*366  # +/- days from build date to look for related bridges in state
nbiRowNames     <- rownames(nbiDataFrame)

nonEmptyRows <- FailRowNames[FailDataFrame$MATER!="" & !is.na(FailDataFrame$ITEM43B) & is.na(FailDataFrame$ITEM43A)]

matsToCheck <- c("pc","conc","steel")
for (j in 1:length(matsToCheck)){
  matOptions <- as.integer(ls.StructMat.Fail[[matsToCheck[j]]])
  matOptions <- matOptions[!is.na(matOptions)]
  key_index <- sapply(1:length(nonEmptyRows), function(i) any(ls.StructMat.Fail[[matsToCheck[j]]]==FailDataFrame[nonEmptyRows[i],"MATER"]))
  match_keys <- which(key_index)
  for (i in match_keys){
    if (!is.na(FailDataFrame[nonEmptyRows[i],"YR_BLT"])){
      rowsSimilarBridges <- nbiRowNames[nbiDataFrame$STFIPS  == FailDataFrame[nonEmptyRows[i],"STFIPS"]   &
                                        nbiDataFrame$ITEM43B == FailDataFrame[nonEmptyRows[i], "ITEM43B"] & 
                                        abs(as.numeric(nbiDataFrame$ITEM27 - FailDataFrame[nonEmptyRows[i], "YR_BLT"])) <= yearsBuildRange]
    }
    else{
      rowsSimilarBridges <- nbiRowNames[nbiDataFrame$STFIPS  == FailDataFrame[nonEmptyRows[i],"STFIPS"]   &
                                          nbiDataFrame$ITEM43B == FailDataFrame[nonEmptyRows[i], "ITEM43B"]]
    }
    if (length(rowsSimilarBridges) == 0){
      print(paste("No matched bridges for i = ",i))
    }
      
    typeOptions      <- table(nbiDataFrame[rowsSimilarBridges ,"ITEM43A"])
    typeOptions      <- typeOptions[order(typeOptions, decreasing=TRUE)]
    typeOptions      <- names(typeOptions)
    firstCommonType  <- typeOptions[typeOptions %in% matOptions][1]
    if(is.null(firstCommonType)){
      print(paste("No common type for i = ",i))
    }
    else{
      FailDataFrame[nonEmptyRows[i],"ITEM43A"]    <- firstCommonType
      FailDataFrame[nonEmptyRows[i],"FLAG_TYPES"] <- FailDataFrame[nonEmptyRows[i],"FLAG_TYPES"] + 3
    }
  }
}

# # now when has material but not type
# nonEmptyRows <- FailRowNames[FailDataFrame$MATER!="" & is.na(FailDataFrame$ITEM43B) & is.na(FailDataFrame$ITEM43A)]
# 
# # assess frequency of occurence in NBI population and assign--if option for simple or continuous, choose more frequent
# simpleOrContinuous <- c(pc    = ifelse(sum(countsNBI["5",]) > sum(countsNBI["6",]), 1, 2),
#                            conc  = ifelse(sum(countsNBI["1",]) > sum(countsNBI["2",]), 1, 2),
#                            steel = ifelse(sum(countsNBI["3",]) > sum(countsNBI["4",]), 1, 2)
#                            )
# 
# # first for pc, steel, conc
# matsToCheck <- c("pc","conc","steel")
# for (j in 1:length(matsToCheck)){
#   matOptions <- as.integer(ls.StructMat.Fail[[matsToCheck[j]]])
#   matOptions <- matOptions[!is.na(matOptions)]
#   key_index <- sapply(1:length(nonEmptyRows), function(i) any(ls.StructMat.Fail[[matsToCheck[j]]]==FailDataFrame[nonEmptyRows[i],"MATER"]))
#   match_keys <- which(key_index)
#   for (i in match_keys){
#     FailDataFrame[nonEmptyRows[i],"ITEM43A"]    <- matOptions[simpleOrContinuous[matsToCheck[j]]]
#     FailDataFrame[nonEmptyRows[i],"ITEM43B"]    <- typesMostFrequent[as.character(FailDataFrame[nonEmptyRows[i],"ITEM43A"])]
#     FailDataFrame[nonEmptyRows[i],"FLAG_TYPES"] <- FailDataFrame[nonEmptyRows[i],"FLAG_TYPES"] + 7
#   }
# }
# 
# # for other types
# nonEmptyRows <- FailRowNames[FailDataFrame$MATER!="" & is.na(FailDataFrame$ITEM43B)]
# 
# matsToCheck <- c("wood", "masonry", "metal", "other")
# for (j in 1:length(matsToCheck)){
#   key_index <- sapply(1:length(nonEmptyRows), function(i) any(ls.StructMat.Fail[[matsToCheck[j]]]==FailDataFrame[nonEmptyRows[i],"MATER"]))
#   match_keys <- which(key_index)
#   for (i in match_keys){
#     FailDataFrame[nonEmptyRows[i],"ITEM43B"]    <- typesMostFrequent[as.character(FailDataFrame[nonEmptyRows[i],"ITEM43A"])]
#     FailDataFrame[nonEmptyRows[i],"FLAG_TYPES"] <- FailDataFrame[nonEmptyRows[i],"FLAG_TYPES"] + 7
#   }
# }

savefile <- paste(gsub("-","",Sys.Date()),"FailDataFrameWithNBImatAndTypeCodes.RData",sep="_")
save(FailDataFrame, file=file.path(dirs$DataDirAnalysis,savefile))
rm(savefile)

## NOW COMPARE HISTOGRAM OF FAILED BRIDGES AND NBI
countsFail <- table(FailDataFrame[,c("ITEM43A","ITEM43B")])
df.mats                <- data.frame(MAT=c(levels(factor(nbiDataFrame$ITEM43A)), levels(factor(FailDataFrame$ITEM43A))),COUNT=NA,DATA=NA)
df.mats[1:10,"COUNT"]  <- sapply(levels(factor(nbiDataFrame$ITEM43A)), function(t) sum(nbiDataFrame[!is.na(nbiDataFrame$ITEM43A),"ITEM43A"]==t))
df.mats[1:10,"DATA"]   <- "NBI_WATER"
df.mats[11:19,"COUNT"] <- sapply(levels(factor(FailDataFrame$ITEM43A)), function(t) sum(FailDataFrame[!is.na(FailDataFrame$ITEM43A),"ITEM43A"]==t))
df.mats[11:19,"DATA"]  <- "FAIL_WATER"
df.mats[1:10,"FREQ"]   <-  df.mats[1:10,"COUNT"]/sum(df.mats[1:10,"COUNT"])
df.mats[11:19,"FREQ"]  <-  df.mats[11:19,"COUNT"]/sum(df.mats[11:19,"COUNT"])
hist2 <- ggplot(df.mats,aes(x=MAT,y=FREQ,fill=factor(DATA))) + geom_bar(stat="identity",position="dodge")

# much more frequent on 3, steel, a bit low on 1 concrete, low on 5 prestress, high on 7
# I'm sure the timber characterizations are correct, so 7 is ok
# makes sense that less prestressed in database as mostly older bridges
# not sure why so high on steel-maybe some of the i-beam types should be assigned to 4?
# but 4 not common in NBI

