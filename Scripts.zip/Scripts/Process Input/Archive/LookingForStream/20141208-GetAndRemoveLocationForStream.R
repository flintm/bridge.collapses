# FUNCTION THAT FINDS MATCHES TO KEYWORD STRINGS IN THE ROAD_NAME FIELD, REMOVES STRINGS AS APPROPRIATE,
# AND APPENDS TO APPROPRIATE CATEGORY
# WRITTEN BY MADELEINE FLINT, DECEMBER 2014
# THIS VERSION IS A TEST VERSION FOR REMOVING RIVER KEYWORDS, WHERE RIVER NAME MAY BE MULTIPLE WORDS
# STEPS
#  1. Split incoming string into substrings by punctuation
#  2. Grepl substrings for LocMatch (here LocMatch == stream keyword)
#  3. For substrings with a grepl match, check for presence of road keywords in substring
#     a. If there is a road keyword, return
#     b. If there is not a road keyword, check first word in next substring (if not already in last substring)
#     c. If there is a road keyword, return, if not, go to step 4
#  4. Return all substrings except matching substring
#  5. If "STREAM_NAME_2" does not match "STREAM_NAME" then write; write type

GetAndRemoveLocationForStream <- function(FailDataRow, LocMatch, ReplaceWord, LocProcessColsOut,ls.JurisdictionKeys, ls.RoadKeys, ls.StreamKeys){
  # 1. STEP 1
  split_strings  <- unlist(strsplit(FailDataRow[,"ROAD_NAME"],"[[:punct:]]"))
  substr_w_loc_match <- which(grepl(paste("\\<",LocMatch,"\\>",sep=""),split_strings))
  if (length(substr_w_loc_match)>1) print("****Had LOCATION with multiple stream keywords")
  if (length(substr_w_loc_match)==0){
    return(FailDataRow[,LocProcessColsOut])
  }
  nSplits        <- length(split_strings)
  substr_wo_match <- 1:nSplits
  substr_wo_match <- substr_wo_match[!(substr_wo_match %in% substr_w_loc_match)]
  match_words_rd <- c(ls.RoadKeys$avenue,ls.RoadKeys$road[1:2],ls.RoadKeys$street)
  has_rd         <- unlist(lapply(c(paste("\\<",match_words_rd,"\\>", sep="")), grepl, split_strings[substr_w_loc_match]))
  has_bridge <- unlist(lapply(c(paste("\\<",ls.RoadKeys$bridge,"\\>", sep="")), grepl, split_strings[substr_w_loc_match]))
  if (any(has_rd)){
    if (any(has_bridge)){
      bridge_word    <- ls.RoadKeys$bridge[has_bridge]
      match_start    <- regexpr(paste("\\<",bridge_word,"\\>", sep=""),split_strings[substr_w_loc_match])
      match_last     <- match_start + attr(match_start, "match.length") - 1
      road_word      <- match_words_rd[has_rd]
      match_rd_start <- regexpr(paste("\\<",road_word,"\\>", sep=""),split_strings[substr_w_loc_match])
      match_rd_last  <- match_start + attr(match_rd_start, "match.length") - 1
      if (match_start > match_rd_start){
        temp_entry     <- split_strings[substr_w_loc_match]
#         FailDataRow[,"BRIDGE_NAME"] <- paste(substr(temp_entry,1,match_start-1),substr(temp_entry,match_last+1,nchar(temp_entry)),sep=" ")
        FailDataRow[,"BRIDGE_NAME"] <- substr(temp_entry,1,match_start-1)
        FailDataRow[,"ROAD_NAME"]   <- paste(substr(temp_entry,1,match_start-1),substr(temp_entry,match_last+1,nchar(temp_entry)),unlist(split_strings)[substr_wo_match],sep=",",collapse=",")
      }
    }
    return(FailDataRow[,LocProcessColsOut])
  }
  else{
    if (substr_w_loc_match < nSplits){
      next_word        <- strsplit(split_strings[substr_w_loc_match+1],"[[:space:]]")[1]
      next_word_has_rd <- unlist(lapply(c(paste("\\<",match_words_rd,"\\>", sep="")), grepl, next_word))
    }
    else next_word_has_rd <- FALSE
    if (any(next_word_has_rd)){
      return(FailDataRow[,LocProcessColsOut])
    }
    else{
      match_start    <- regexpr(paste("\\<",LocMatch,"\\>", sep=""),split_strings[substr_w_loc_match])
      match_last     <- match_start + attr(match_start, "match.length") - 1
      temp_entry     <- split_strings[substr_w_loc_match]
      if (any(has_bridge)){
        bridge_word    <- ls.RoadKeys$bridge[has_bridge]
        match_br_start <- regexpr(paste("\\<",bridge_word,"\\>", sep=""),split_strings[substr_w_loc_match])
        match_br_last  <- match_start + attr(match_start, "match.length") - 1
        if (match_start > match_br_start){
          temp_entry     <- split_strings[substr_w_loc_match]
          FailDataRow[,"BRIDGE_NAME"] <- paste(substr(temp_entry,1,match_br_start-1),substr(temp_entry,match_br_last+1,nchar(temp_entry)),sep=" ")
          FailDataRow[,"ROAD_NAME"]   <- paste(substr(temp_entry,1,match_br_start-1),substr(temp_entry,match_br_last+1,nchar(temp_entry)),unlist(split_strings)[substr_wo_match],sep=",",collapse=",")
          FailDataRow[,"STREAM_NAME_FROM_LOC"] <- substr(temp_entry,1,match_start-1)
          FailDataRow[,"STREAM_TYPE_FROM_LOC"] <- ReplaceWord
        }
      }
      else{
        FailDataRow[,"STREAM_NAME_FROM_LOC"] <- paste(substr(temp_entry,1,match_start-1),substr(temp_entry,match_last+1,nchar(temp_entry)),sep=" ")
        FailDataRow[,"STREAM_TYPE_FROM_LOC"] <- ReplaceWord
        FailDataRow[,"ROAD_NAME"]     <- paste(unlist(split_strings)[substr_wo_match],collapse=",")
      }
    }    
  }
  return(FailDataRow[,LocProcessColsOut])
}

